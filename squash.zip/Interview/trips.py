from flask import Flask, jsonify, request
import datetime
app = Flask(__name__)

@app.route("/trips/timeOpenings", methods=['GET'])
'''
    Returns a list of all available timeOpenings for the current week.
'''
def openings():
    now = datetime.datetime.now()
    h = now.hour
    d = now.day
    if (h >= 6 and h < 11):
        '''Checks to see if user is sending GET request for rides home before the deadline'''
        return jsonify({
            id: UUID,
            requestDeadline: 11,
            timeSelectionRange: (6, 11),
            timeSelectionIntervalMinutes: 5
        })
    elif (h < 21):
        '''Checks to see if user is sending GET request for rides to work before the deadline'''

@app.route("/trips/requests", methods=['POST'])
'''
    Creates a trip request for a time opening, mode, and time range.
'''
def create():

@app.route("/trips/requests/:requestId", methods=['PUT'])
'''
    Modifies a request to cancel or delete. Must be before deadline.
'''
def change():


if __name__ == '__main__':
    app.run(debug=True)
